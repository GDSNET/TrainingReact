import React from 'react';
import {TouchableOpacity, Text, View, StyleSheet} from 'react-native-web'
import { Component } from "react";




class ComponenteDerecho extends Component {

  render(){
  return (
<View styles={styles1.container}>


      <Text>hola componente derecho  </Text>
      

</View>
  );
}
}

export default ComponenteDerecho;



const styles1 = StyleSheet.create({
  container: {

    backgroundColor:'#e6ffe6'
  }
});
const styles2 = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'column',
  }
});
