import React from 'react';
import logo from './logo.svg';
import './App.css';
import {TouchableOpacity, Text, View, StyleSheet} from 'react-native-web'
import { Component } from "react";
import Datos from "./APIS/ArbolesJSON.json"
import ComponenteDerecho from './Components/ComponenteDerecho'


class Main extends Component {

  renderMatias(){
const data = Datos
try {
return data.map((value,i)=> {
    return value.arboles.map((subvalue,i)=>{
          return(

          <TouchableOpacity>{subvalue.especie}</TouchableOpacity>
          )
        })
}
)
} catch (error) {
  alert(error)
}
}

  render(){
  return (
<View>
    
    <ComponenteDerecho />

</View>
  );
}
}

export default Main;
